#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 _ProjectionParams;
uniform 	vec4 cubism_MaskTile;
uniform 	vec4 cubism_MaskTransform;
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in highp vec2 in_TEXCOORD0;
mediump vec4 vs_COLOR0;
out highp vec2 vs_TEXCOORD0;
vec3 u_xlat0;
vec4 u_xlat1;
float u_xlat4;
void main()
{
    u_xlat0.xy = cubism_MaskTile.yz + vec2(0.5, 0.5);
    u_xlat0.xy = u_xlat0.xy * cubism_MaskTile.ww;
    u_xlat4 = cubism_MaskTile.w * cubism_MaskTransform.z;
    u_xlat1.xy = in_POSITION0.xy + (-cubism_MaskTransform.xy);
    u_xlat0.xy = u_xlat1.xy * vec2(u_xlat4) + u_xlat0.xy;
    u_xlat1.x = float(2.0);
    u_xlat1.z = float(1.0);
    u_xlat1.yw = _ProjectionParams.xx;
    u_xlat0.xy = u_xlat0.xy * u_xlat1.xy;
    u_xlat0.z = u_xlat0.y * 2.0;
    gl_Position.xy = (-u_xlat1.zw) + u_xlat0.xz;
    gl_Position.zw = vec2(1.0, 1.0);
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec4 cubism_MaskTile;
UNITY_LOCATION(0) uniform mediump sampler2D _MainTex;
in highp  vec2 vs_TEXCOORD0;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
bvec4 u_xlatb0;
mediump float u_xlat16_1;
void main()
{
    u_xlatb0 = equal(cubism_MaskTile.xxxx, vec4(0.0, 1.0, 2.0, 3.0));
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
    u_xlat0.z = u_xlatb0.z ? float(1.0) : 0.0;
    u_xlat0.w = u_xlatb0.w ? float(1.0) : 0.0;
;
    u_xlat16_1 = texture(_MainTex, vs_TEXCOORD0.xy).w;
    u_xlat0 = u_xlat0 * vec4(u_xlat16_1);
    SV_Target0 = u_xlat0;
    return;
}

#endif
