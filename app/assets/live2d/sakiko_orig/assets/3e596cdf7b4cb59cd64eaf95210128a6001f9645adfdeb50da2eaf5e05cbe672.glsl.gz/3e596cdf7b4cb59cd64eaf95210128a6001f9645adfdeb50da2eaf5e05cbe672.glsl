#ifdef VERTEX
#version 300 es

#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	mediump vec4 _AdditionalLightsCount;
uniform 	vec4 _AdditionalLightsPosition[16];
uniform 	mediump vec4 _AdditionalLightsColor[16];
uniform 	mediump vec4 _AdditionalLightsAttenuation[16];
uniform 	mediump vec4 _AdditionalLightsSpotDir[16];
uniform 	vec4 _ProjectionParams;
uniform 	vec4 hlslcc_mtx4x4unity_MatrixVP[4];
uniform 	vec4 cubism_MaskTile;
uniform 	vec4 cubism_MaskTransform;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_Rotation;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_Rotation;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
in highp vec4 in_POSITION0;
in mediump vec4 in_COLOR0;
in mediump vec2 in_TEXCOORD0;
in mediump vec4 in_TANGENT0;
in mediump vec4 in_NORMAL0;
out mediump vec4 vs_COLOR0;
out mediump vec2 vs_TEXCOORD0;
out highp vec2 vs_TEXCOORD3;
out mediump vec3 vs_TEXCOORD1;
mediump vec3 vs_TEXCOORD2;
mediump vec3 vs_TEXCOORD9;
highp vec4 vs_TEXCOORD4;
out mediump vec3 vs_TEXCOORD6;
out mediump vec3 vs_TEXCOORD7;
out highp vec4 vs_TEXCOORD8;
vec4 u_xlat0;
vec4 u_xlat1;
vec4 u_xlat2;
vec3 u_xlat3;
vec3 u_xlat4;
vec3 u_xlat5;
bool u_xlatb5;
vec3 u_xlat6;
mediump vec3 u_xlat16_6;
vec3 u_xlat7;
mediump vec3 u_xlat16_7;
float u_xlat8;
float u_xlat11;
vec2 u_xlat23;
float u_xlat29;
uint u_xlatu29;
bool u_xlatb29;
float u_xlat30;
uint u_xlatu31;
float u_xlat32;
mediump float u_xlat16_33;
void main()
{
    u_xlat0 = in_POSITION0.yyyy * hlslcc_mtx4x4unity_ObjectToWorld[1];
    u_xlat0 = hlslcc_mtx4x4unity_ObjectToWorld[0] * in_POSITION0.xxxx + u_xlat0;
    u_xlat0 = hlslcc_mtx4x4unity_ObjectToWorld[2] * in_POSITION0.zzzz + u_xlat0;
    u_xlat1 = u_xlat0 + hlslcc_mtx4x4unity_ObjectToWorld[3];
    u_xlat2 = u_xlat1.yyyy * hlslcc_mtx4x4unity_MatrixVP[1];
    u_xlat2 = hlslcc_mtx4x4unity_MatrixVP[0] * u_xlat1.xxxx + u_xlat2;
    u_xlat2 = hlslcc_mtx4x4unity_MatrixVP[2] * u_xlat1.zzzz + u_xlat2;
    u_xlat1 = hlslcc_mtx4x4unity_MatrixVP[3] * u_xlat1.wwww + u_xlat2;
    u_xlat2.xz = u_xlat1.xw * vec2(0.5, 0.5);
    u_xlat11 = u_xlat1.y * _ProjectionParams.x;
    u_xlat2.w = u_xlat11 * 0.5;
    vs_TEXCOORD8.xy = u_xlat2.zz + u_xlat2.xw;
    u_xlat2.xyz = in_NORMAL0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_NORMAL0.xxx + u_xlat2.xyz;
    u_xlat2.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_NORMAL0.zzz + u_xlat2.xyz;
    u_xlat29 = dot(u_xlat2.xyz, u_xlat2.xyz);
    u_xlat29 = inversesqrt(u_xlat29);
    u_xlat2.xyz = vec3(u_xlat29) * u_xlat2.xyz;
    u_xlat3.xyz = in_TANGENT0.yyy * hlslcc_mtx4x4unity_ObjectToWorld[1].xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[0].xyz * in_TANGENT0.xxx + u_xlat3.xyz;
    u_xlat3.xyz = hlslcc_mtx4x4unity_ObjectToWorld[2].xyz * in_TANGENT0.zzz + u_xlat3.xyz;
    u_xlat29 = dot(u_xlat3.xyz, u_xlat3.xyz);
    u_xlat29 = inversesqrt(u_xlat29);
    u_xlat3.xyz = vec3(u_xlat29) * u_xlat3.xyz;
    u_xlat4.xyz = u_xlat2.zxy * u_xlat3.yzx;
    u_xlat4.xyz = u_xlat2.yzx * u_xlat3.zxy + (-u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * in_TANGENT0.www;
    u_xlat0 = hlslcc_mtx4x4unity_ObjectToWorld[3] * in_POSITION0.wwww + u_xlat0;
    u_xlat29 = cubism_MaskTile.w * cubism_MaskTransform.z;
    u_xlat5.xy = cubism_MaskTile.yz + vec2(0.5, 0.5);
    u_xlat5.xy = u_xlat5.xy * cubism_MaskTile.ww;
    u_xlat23.xy = in_POSITION0.xy + (-cubism_MaskTransform.xy);
    vs_TEXCOORD3.xy = u_xlat23.xy * vec2(u_xlat29) + u_xlat5.xy;
    u_xlat16_6.x = min(_AdditionalLightsCount.x, unity_LightData.y);
    u_xlatu29 =  uint(int(u_xlat16_6.x));
    u_xlat16_6.x = float(0.0);
    u_xlat16_6.y = float(0.0);
    u_xlat16_6.z = float(0.0);
    u_xlat16_7.x = float(0.0);
    u_xlat16_7.y = float(0.0);
    u_xlat16_7.z = float(0.0);
    u_xlat30 = 0.0;
    u_xlatu31 = uint(0u);
    while(true){
        u_xlatb5 = u_xlatu31>=u_xlatu29;
        if(u_xlatb5){break;}
        u_xlat5.xyz = (-u_xlat0.xyz) * _AdditionalLightsPosition[int(u_xlatu31)].www + _AdditionalLightsPosition[int(u_xlatu31)].xyz;
        u_xlat32 = dot(u_xlat5.xyz, u_xlat5.xyz);
        u_xlat32 = max(u_xlat32, 6.10351562e-05);
        u_xlat8 = inversesqrt(u_xlat32);
        u_xlat5.xyz = u_xlat5.xyz * vec3(u_xlat8);
        u_xlat8 = float(1.0) / float(u_xlat32);
        u_xlat32 = u_xlat32 * _AdditionalLightsAttenuation[int(u_xlatu31)].x;
        u_xlat16_33 = (-u_xlat32) * u_xlat32 + 1.0;
        u_xlat16_33 = max(u_xlat16_33, 0.0);
        u_xlat16_33 = u_xlat16_33 * u_xlat16_33;
        u_xlat32 = u_xlat16_33 * u_xlat8;
        u_xlat16_33 = dot(_AdditionalLightsSpotDir[int(u_xlatu31)].xyz, u_xlat5.xyz);
        u_xlat16_33 = u_xlat16_33 * _AdditionalLightsAttenuation[int(u_xlatu31)].z + _AdditionalLightsAttenuation[int(u_xlatu31)].w;
        u_xlat16_33 = clamp(u_xlat16_33, 0.0, 1.0);
        u_xlat16_33 = u_xlat16_33 * u_xlat16_33;
        u_xlat8 = u_xlat32 * u_xlat16_33;
        u_xlat7.xyz = u_xlat5.xyz * vec3(u_xlat8) + u_xlat16_7.xyz;
        u_xlat6.xyz = _AdditionalLightsColor[int(u_xlatu31)].xyz * vec3(u_xlat8) + u_xlat16_6.xyz;
        u_xlat30 = u_xlat32 * u_xlat16_33 + u_xlat30;
        u_xlatu31 = u_xlatu31 + 1u;
        u_xlat16_6.xyz = u_xlat6.xyz;
        u_xlat16_7.xyz = u_xlat7.xyz;
    }
    vs_TEXCOORD6.xyz = u_xlat16_6.xyz;
    u_xlatb29 = 0.0<u_xlat30;
    u_xlat5.xyz = u_xlat16_7.xyz / vec3(u_xlat30);
    u_xlat30 = dot(u_xlat5.xyz, u_xlat5.xyz);
    u_xlat30 = inversesqrt(u_xlat30);
    u_xlat5.xyz = vec3(u_xlat30) * u_xlat5.xyz;
    u_xlat5.xyz = (bool(u_xlatb29)) ? u_xlat5.xyz : vec3(0.0, 0.0, 1.0);
    gl_Position = u_xlat1;
    vs_COLOR0 = in_COLOR0;
    vs_TEXCOORD1.xyz = u_xlat2.xyz;
    vs_TEXCOORD2.xyz = u_xlat3.xyz;
    vs_TEXCOORD9.xyz = u_xlat4.xyz;
    vs_TEXCOORD0.xy = in_TEXCOORD0.xy;
    vs_TEXCOORD4 = u_xlat0;
    vs_TEXCOORD7.xyz = u_xlat5.xyz;
    vs_TEXCOORD8.zw = u_xlat1.zw;
    return;
}

#endif
#ifdef FRAGMENT
#version 300 es

precision highp float;
precision highp int;
#define HLSLCC_ENABLE_UNIFORM_BUFFERS 1
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
#define UNITY_UNIFORM
#else
#define UNITY_UNIFORM uniform
#endif
#define UNITY_SUPPORTS_UNIFORM_LOCATION 1
#if UNITY_SUPPORTS_UNIFORM_LOCATION
#define UNITY_LOCATION(x) layout(location = x)
#define UNITY_BINDING(x) layout(binding = x, std140)
#else
#define UNITY_LOCATION(x)
#define UNITY_BINDING(x) layout(std140)
#endif
uniform 	vec2 _GlobalMipBias;
uniform 	vec4 _MainLightPosition;
uniform 	mediump vec4 _MainLightColor;
uniform 	vec4 _Time;
uniform 	mediump vec4 cubism_MultiplyColor;
uniform 	mediump float _LightingEnabled;
uniform 	mediump float _UseMultiplyTex;
uniform 	mediump vec4 _MultiplyUV;
uniform 	mediump float _MultiplyTexIntensity;
uniform 	mediump vec4 _MultiplyTexAmplitude;
uniform 	mediump float _MultiplyTexFrequency;
uniform 	float cubism_ModelOpacity;
uniform 	vec4 cubism_MaskTile;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
UNITY_BINDING(0) uniform UnityPerDraw {
#endif
	UNITY_UNIFORM vec4                hlslcc_mtx4x4unity_ObjectToWorld[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_WorldToObject[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LODFade;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_WorldTransformParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RenderingLayer;
	UNITY_UNIFORM mediump vec4                unity_LightData;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_LightIndices[2];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_ProbesOcclusion;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube0_HDR;
	UNITY_UNIFORM mediump vec4 Xhlslcc_UnusedXunity_SpecCube1_HDR;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube0_Rotation;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMax;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_BoxMin;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_ProbePosition;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpecCube1_Rotation;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_LightmapST;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_DynamicLightmapST;
	UNITY_UNIFORM mediump vec4                unity_SHAr;
	UNITY_UNIFORM mediump vec4                unity_SHAg;
	UNITY_UNIFORM mediump vec4                unity_SHAb;
	UNITY_UNIFORM mediump vec4                unity_SHBr;
	UNITY_UNIFORM mediump vec4                unity_SHBg;
	UNITY_UNIFORM mediump vec4                unity_SHBb;
	UNITY_UNIFORM mediump vec4                unity_SHC;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Min;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_RendererBounds_Max;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousM[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXhlslcc_mtx4x4unity_MatrixPreviousMI[4];
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_MotionVectorsParams;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteColor;
	UNITY_UNIFORM vec4 Xhlslcc_UnusedXunity_SpriteProps;
#if HLSLCC_ENABLE_UNIFORM_BUFFERS
};
#endif
UNITY_LOCATION(0) uniform mediump sampler2D cubism_MaskTexture;
UNITY_LOCATION(1) uniform mediump sampler2D _MainTex;
UNITY_LOCATION(2) uniform mediump sampler2D _MultiplyTex;
in mediump  vec4 vs_COLOR0;
in mediump  vec2 vs_TEXCOORD0;
in highp  vec2 vs_TEXCOORD3;
in mediump  vec3 vs_TEXCOORD1;
in mediump  vec3 vs_TEXCOORD6;
in mediump  vec3 vs_TEXCOORD7;
in highp  vec4 vs_TEXCOORD8;
layout(location = 0) out mediump vec4 SV_Target0;
vec4 u_xlat0;
mediump vec4 u_xlat16_0;
bvec4 u_xlatb0;
mediump vec4 u_xlat16_1;
mediump vec4 u_xlat16_2;
mediump vec3 u_xlat16_3;
vec3 u_xlat4;
mediump vec3 u_xlat16_4;
bvec2 u_xlatb4;
bvec3 u_xlatb5;
vec2 u_xlat10;
bvec2 u_xlatb10;
mediump float u_xlat16_18;
void main()
{
    u_xlat16_0.x = dot(vs_TEXCOORD1.xyz, vs_TEXCOORD1.xyz);
    u_xlat16_0.x = inversesqrt(u_xlat16_0.x);
    u_xlat16_0.xyz = u_xlat16_0.xxx * vs_TEXCOORD1.xyz;
    u_xlat16_1.x = u_xlat16_0.y * u_xlat16_0.y;
    u_xlat16_1.x = u_xlat16_0.x * u_xlat16_0.x + (-u_xlat16_1.x);
    u_xlat16_2 = u_xlat16_0.yzzx * u_xlat16_0.xyzz;
    u_xlat16_3.x = dot(unity_SHBr, u_xlat16_2);
    u_xlat16_3.y = dot(unity_SHBg, u_xlat16_2);
    u_xlat16_3.z = dot(unity_SHBb, u_xlat16_2);
    u_xlat16_1.xyz = unity_SHC.xyz * u_xlat16_1.xxx + u_xlat16_3.xyz;
    u_xlat16_0.w = 1.0;
    u_xlat16_2.x = dot(unity_SHAr, u_xlat16_0);
    u_xlat16_2.y = dot(unity_SHAg, u_xlat16_0);
    u_xlat16_2.z = dot(unity_SHAb, u_xlat16_0);
    u_xlat16_1.xyz = u_xlat16_1.xyz + u_xlat16_2.xyz;
    u_xlat4.xyz = log2(abs(u_xlat16_1.xyz));
    u_xlat4.xyz = u_xlat4.xyz * vec3(0.416666657, 0.416666657, 0.416666657);
    u_xlat4.xyz = exp2(u_xlat4.xyz);
    u_xlat4.xyz = u_xlat4.xyz * vec3(1.05499995, 1.05499995, 1.05499995) + vec3(-0.0549999997, -0.0549999997, -0.0549999997);
    u_xlatb5.xyz = greaterThanEqual(vec4(0.00313080009, 0.00313080009, 0.00313080009, 0.0), u_xlat16_1.xyzx).xyz;
    u_xlat16_1.xyz = u_xlat16_1.xyz * vec3(12.9232101, 12.9232101, 12.9232101);
    {
        vec3 hlslcc_movcTemp = u_xlat4;
        hlslcc_movcTemp.x = (u_xlatb5.x) ? u_xlat16_1.x : u_xlat4.x;
        hlslcc_movcTemp.y = (u_xlatb5.y) ? u_xlat16_1.y : u_xlat4.y;
        hlslcc_movcTemp.z = (u_xlatb5.z) ? u_xlat16_1.z : u_xlat4.z;
        u_xlat4 = hlslcc_movcTemp;
    }
    u_xlat16_18 = dot(vs_TEXCOORD7.xyz, vs_TEXCOORD7.xyz);
    u_xlat16_18 = inversesqrt(u_xlat16_18);
    u_xlat16_1.xyz = vec3(u_xlat16_18) * vs_TEXCOORD7.xyz;
    u_xlat16_18 = dot(u_xlat16_0.xyz, u_xlat16_1.xyz);
    u_xlat16_18 = max(u_xlat16_18, 0.0);
    u_xlat16_1.xyz = vec3(u_xlat16_18) * vs_TEXCOORD6.xyz;
    u_xlat16_18 = dot(_MainLightPosition.xyz, _MainLightPosition.xyz);
    u_xlat16_18 = inversesqrt(u_xlat16_18);
    u_xlat16_2.xyz = vec3(u_xlat16_18) * _MainLightPosition.xyz;
    u_xlat16_0.x = dot(u_xlat16_0.xyz, (-u_xlat16_2.xyz));
    u_xlat16_0.x = max(u_xlat16_0.x, 0.0);
    u_xlat16_0.xyz = _MainLightColor.xyz * u_xlat16_0.xxx + u_xlat16_1.xyz;
    u_xlat16_0.xyz = u_xlat16_0.xyz * u_xlat4.xyz + vec3(-1.0, -1.0, -1.0);
    u_xlat16_0.xyz = vec3(_LightingEnabled) * u_xlat16_0.xyz + vec3(1.0, 1.0, 1.0);
    u_xlat16_1 = texture(_MainTex, vs_TEXCOORD0.xy, _GlobalMipBias.x);
    u_xlat16_2.xyz = u_xlat16_1.xyz * cubism_MultiplyColor.xyz;
    u_xlat16_1.w = u_xlat16_1.w * vs_COLOR0.w;
    u_xlat16_2.xyz = u_xlat16_2.xyz * vs_COLOR0.xyz;
    u_xlat16_0.xyz = u_xlat16_0.xyz * u_xlat16_2.xyz;
    u_xlat16_18 = _Time.y * _MultiplyTexFrequency;
    u_xlat16_18 = u_xlat16_18 * 6.28318548;
    u_xlat16_18 = sin(u_xlat16_18);
    u_xlat4.xy = vs_TEXCOORD8.xy / vs_TEXCOORD8.ww;
    u_xlat16_2.xy = u_xlat4.xy * _MultiplyUV.xy + _MultiplyUV.zw;
    u_xlat16_2.xy = _MultiplyTexAmplitude.xy * vec2(u_xlat16_18) + u_xlat16_2.xy;
    u_xlat16_4.xyz = texture(_MultiplyTex, u_xlat16_2.xy, _GlobalMipBias.x).xyz;
    u_xlat16_2.xyz = u_xlat16_0.xyz * u_xlat16_4.xyz + (-u_xlat16_0.xyz);
    u_xlat16_2.xyz = u_xlat16_2.xyz * vec3(_MultiplyTexIntensity);
    u_xlat16_0.xyz = vec3(vec3(_UseMultiplyTex, _UseMultiplyTex, _UseMultiplyTex)) * u_xlat16_2.xyz + u_xlat16_0.xyz;
    u_xlat16_1.xyz = u_xlat16_1.www * u_xlat16_0.xyz;
    u_xlat4.xy = cubism_MaskTile.ww * cubism_MaskTile.yz;
    u_xlatb4.xy = greaterThanEqual(vs_TEXCOORD3.xyxx, u_xlat4.xyxx).xy;
    u_xlat4.x = u_xlatb4.x ? float(1.0) : 0.0;
    u_xlat4.y = u_xlatb4.y ? float(1.0) : 0.0;
;
    u_xlat4.x = u_xlat4.y * u_xlat4.x;
    u_xlat10.xy = cubism_MaskTile.yz * cubism_MaskTile.ww + cubism_MaskTile.ww;
    u_xlatb10.xy = greaterThanEqual(u_xlat10.xyxx, vs_TEXCOORD3.xyxx).xy;
    u_xlat10.x = u_xlatb10.x ? float(1.0) : 0.0;
    u_xlat10.y = u_xlatb10.y ? float(1.0) : 0.0;
;
    u_xlat4.x = u_xlat10.x * u_xlat4.x;
    u_xlat4.x = u_xlat10.y * u_xlat4.x;
    u_xlatb0 = equal(cubism_MaskTile.xxxx, vec4(0.0, 1.0, 2.0, 3.0));
    u_xlat0.x = u_xlatb0.x ? float(1.0) : 0.0;
    u_xlat0.y = u_xlatb0.y ? float(1.0) : 0.0;
    u_xlat0.z = u_xlatb0.z ? float(1.0) : 0.0;
    u_xlat0.w = u_xlatb0.w ? float(1.0) : 0.0;
;
    u_xlat0 = u_xlat4.xxxx * u_xlat0;
    u_xlat16_2 = texture(cubism_MaskTexture, vs_TEXCOORD3.xy);
    u_xlat4.xy = u_xlat0.xy * u_xlat16_2.xy;
    u_xlat4.x = u_xlat4.y + u_xlat4.x;
    u_xlat4.x = u_xlat16_2.z * u_xlat0.z + u_xlat4.x;
    u_xlat4.x = u_xlat16_2.w * u_xlat0.w + u_xlat4.x;
    u_xlat0 = u_xlat16_1 * u_xlat4.xxxx;
    u_xlat0 = u_xlat0 * vec4(cubism_ModelOpacity);
    SV_Target0 = u_xlat0;
    return;
}

#endif
